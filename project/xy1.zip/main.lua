require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"

--activity.setTheme(R.AndLua1)
activity.setTitle("密码加入软件")

layout1={
  LinearLayout;
  orientation="vertical";
  layout_width="fill";
  layout_height="fill";
  {
    EditText;
    singleLine="true";
    id="密码";
    hint="请输入密码";
    layout_width="match_parent";
  };
  {
    Button;
    id="进入",
  };
};



activity.setContentView(loadlayout(layout1))

进入.onClick=function()
  if #密码.text~=0 then
if 密码.text=="密码" then
    activity.setContentView(loadlayout(layout))
  end
end
end
--[[
进入.onClick=function()
  if #密码.text~=0 then
if 密码.text:match("密码") then
    activity.setContentView(loadlayout(layout))
  end
end
end
如果输入的密码中含有某数，则进入密码之前的页面
小白专用
--[[/**
*
*----------Dragon be here!----------/
* 　　　┏┓　　　┏┓
* 　　┏┛┻━━━┛┻┓
* 　　┃　　　　　　　┃
* 　　┃　　　━　　　┃
* 　　┃　┳┛　┗┳　┃
* 　　┃　　　　　　　┃
* 　　┃　　　┻　　　┃
* 　　┃　　　　　　　┃
* 　　┗━┓　　　┏━┛
* 　　　　┃　　　┃护国神兽保佑
* 　　　　┃　　　┃代码无BUG！
* 　　　　┃　　　┗━━━┓
* 　　　　┃　　　　　　　┣┓
* 　　　　┃　　　　　　　┏┛
* 　　　　┗┓┓┏━┳┓┏┛
* 　　　　　┃┫┫　┃┫┫
* 　　　　　┗┻┛　┗┻┛
* ━━━━━━神兽出没━━━━━━
*/]]